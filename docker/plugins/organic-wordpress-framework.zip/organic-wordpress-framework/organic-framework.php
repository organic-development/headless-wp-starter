<?php
/**
 * Plugin Name:     Organic Framework
 * Plugin URI:      https://theorganicagency.com
 * Description:     Provides a Wordpress framework for registering custom post types, modules, and blocks.
 * Author:          The Organic Agency
 * Author URI:      https://theorganicagency.com
 * Text Domain:     organic-framework
 * Domain Path:     /languages
 * Version:         0.1.0
 */
