<?php
/**
 * OrganicFramework\CustomPostTypes
 */
namespace OrganicFramework\CustomPostTypes;

use ReflectionClass;
use ReflectionException;
use ReflectionProperty;
use WP_Error;
use WP_Post;

/**
 * This is the abstract class that all custom post types should extend. It provides a lot of the default
 * functionality required when implementing \OrganicFramework\Interfaces\CustomPostTypeInterface.
 *
 * Any abstract methods should be overridden.
 *
 * @package OrganicFramework\Models
 */
abstract class AbstractCustomPostType
{
    /** @var WP_Post|null
     *
     * The WP post data
     */
    protected $post;

    /**
     * __construct
     *
     * @param int|null $postId If supplied, the object will be populated
     */
    public function __construct(int $postId = null)
    {
        if ($postId) {
            try {
                // First of all, populate the core post property
                $this->post = get_post($postId, OBJECT);

                // Populate any properties that have the @meta declaration against them with data from the post meta
                $meta = get_post_meta($postId);
                foreach (self::getMetaProperties() as $property) {
                    $metaKey = self::metaKey($property->name);
                    if (array_key_exists($metaKey, $meta)) {
                        $value = self::getPropertyIsSingle($property) ? $meta[$metaKey][0] : $meta[$metaKey];
                        $property->setAccessible(true);
                        $property->setValue($this, $value);
                    }
                }
            } catch (ReflectionException $e) {
                die($e);
            }
        }
    }

    /**
     * metaKey
     *
     * Generate a meta key suitable for the supplied property name
     *
     * @param string $propertyName The class property the meta data applies to
     *
     * @return string The meta key that will get stored in the database
     */
    public static function metaKey(string $propertyName): string
    {
        return self::getClassName().'.'.$propertyName;
    }

    /**
     * getMetaFields
     *
     * Look at the private properties of the class to determine what meta fields need to be registered.
     * Returns the appropriate Wordpress config array.
     *
     * @return array
     *
     * @throws ReflectionException
     */
    public static function getMetaFields(): array
    {
        $metaFields = [];

        foreach (self::getMetaProperties() as $property) {
            $metaFields[self::metaKey($property->name)] = [
                'show_in_rest' => true,
                'single' => self::getPropertyIsSingle($property),
                'type' => self::getPropertyType($property),
            ];
        }

        return $metaFields;
    }

    /**
     * getKey
     *
     * Returns the main slug/key used by Wordpress for this Custom Post Type
     *
     * @return string
     */
    abstract public static function getKey(): string;

    /**
     * getResultsOrder
     *
     * Determines what order posts should appear in on the list screen in the Admin Area.
     *
     * @return array
     */
    public static function getResultsOrder(): array
    {
        return [
            // Just use Wordpress' default ordering by default
        ];
    }

    /**
     * allowedBlocks
     *
     * Determine which blocks are available to editors when editing this Custom Post Type.
     *
     * @return array
     */
    public static function allowedBlocks()
    {
        // Allow all by default
        return [];
    }

    /**
     * getColumns
     *
     * Determines which columns display on the list screen for this post type in the Admin Area.
     *
     * @return array
     */
    public static function getColumns(): array
    {
        return [];
    }

    /**
     * getFields
     *
     * The list of metabox custom fields used by this Custom Post Type
     *
     * @return array
     */
    public static function getFields(): array
    {
        return [];
    }

    /**
     * useCustomiser
     *
     * Determines whether this post type uses the WP customiser to set its featured image and intro text
     *
     * @return bool
     */
    public static function useCustomiser(): bool
    {
        return false;
    }

    /**
     * getSortingOptions
     *
     * Return the sorting options for use on the archive pages
     *
     * @return array $options
     */
    public static function getSortingOptions(): array
    {
        return
            [
                ['orderBy' => 'date', 'order' => 'DESC', 'label' => 'Date posted: latest to oldest'],
                ['orderBy' => 'date', 'order' => 'ASC', 'label' => 'Date posted: oldest to latest'],
            ];
    }

    /**
     * getPostsPerPage
     *
     * Return the number of posts per page
     *
     * @return int
     */
    public static function getPostsPerPage(): int
    {
        return 10;
    }

    /**
     * getCurrentSorting
     *
     * Return the current sorting selections
     *
     * @return array
     *
     */
    public static function getCurrentSorting(): array
    {
        return [
            'order' => get_query_var('order', 'DESC'),
            'orderBy' => get_query_var('orderBy', 'date'),
        ];
    }

    /**
     * getAvailableTags
     *
     * Return available tags
     *
     * @param String $postTypeKey
     *
     * @return array
     *
     */
    public static function getAvailableTags(string $postTypeKey): array
    {
        $activeTags = [];

        $allPosts = get_posts(
            [
                'post_type' => $postTypeKey,
                'post_status' => 'publish',
                'numberposts' => -1,
            ]
        );

        foreach ($allPosts as $post) {
            $postTags = get_the_terms($post->ID, 'post_tag');

            if (!empty($postTags)) {
                foreach ($postTags as $postTag) {
                    $activeTags[$postTag->term_id] = $postTag->name;
                }
            }
        }

        return $activeTags;
    }

    /**
     * getSnippet
     *
     * Get a summary snippet of text for an instance of this Custom Post Type. Typically this will
     * come from the Wordpress core post excerpt field, but if that is empty, it will attempt to create
     * one from the main post content.
     *
     * @return string
     */
    public function getSnippet()
    {
        $sourceText = ! empty($this->post->post_excerpt) ? $this->post->post_excerpt
            : strip_tags($this->post->post_content);

        return wp_trim_words($sourceText, 25);
    }

    /**
     * getImage
     *
     * Get an HTML string containing an image tag for the post's feature image (also known as the post thumbnail).
     *
     * @param string $size One of the named sizes you have registered for your site (using add_image_size()).
     *
     * @return string
     */
    public function getImage(string $size = 'medium'): string
    {
        return get_the_post_thumbnail($this->post, $size);
    }

    /**
     * getImageUrl
     *
     * Get the URL of the post's featured image (also known as the post thumbnail).
     *
     * @param string $size One of the named sizes you have registered for your site (using add_image_size()).
     *
     * @return string
     */
    public function getImageUrl(string $size = 'full'): string
    {
        return get_the_post_thumbnail_url($this->post, $size);
    }

    /**
     * getLink
     *
     * Get the full front-end URL to an instance of this Custom Post Type
     *
     * @return false|string
     */
    public function getLink()
    {
        return get_permalink($this->post);
    }

    /**
     * getSlug
     *
     * Get the URL-friendly slug for an instance of this Custom Post Type
     *
     * @return string
     */
    public function getSlug()
    {
        return $this->post->post_name;
    }

    /**
     * getTitle
     *
     * Get the main page title for an instance of this Custom Post Type
     *
     * @return string
     */
    public function getTitle(): string
    {
        return $this->post->post_title;
    }

    /**
     * getContent
     *
     * Get the main page content for an instance of this Custom Post Type
     *
     * @return string
     */
    public function getContent(): string
    {
        return $this->post->post_content;
    }

    /**
     * getDate
     *
     * Get the date string for when an instance of this Custom Post Type was published
     *
     * @param string $format
     *
     * @return false|string
     */
    public function getDate(string $format = 'jS F Y'): string
    {
        return date($format, strtotime($this->post->post_date));
    }

    /**
     * getExcerpt
     *
     * Get the contents of the core Wordpress excerpt field for this post
     *
     * @return string
     */
    public function getExcerpt(): string
    {
        return $this->post->post_excerpt;
    }

    /**
     * getTerms
     *
     * Get all the terms (categories and tags) associated with this post
     *
     * @return array|WP_Error
     */
    public function getTerms()
    {
        return wp_get_post_terms($this->getId());
    }

    /**
     * getId
     *
     * Get the primary numeric ID for this post.
     *
     * @return int|null
     */
    public function getId()
    {
        return $this->post->ID ?? null;
    }

    /**
     * getReadingMinutes
     *
     * Find out how long it would take to read this post, in minutes.
     *
     * @return int
     */
    public function getReadingMinutes(): int
    {
        $averageWordsPerMinute = 200;
        $words = count(explode(' ', strip_tags($this->post->post_content_filtered)));

        return max(1, round($words / $averageWordsPerMinute));
    }

    /**
     * getExtendedContent
     *
     * Get the array of extended content (splits content into 'main' and 'more')
     *
     * @return array
     */
    public function getExtendedContent(): array
    {
        return get_extended(get_post_field('post_content', $this->getId()));
    }

    /**
     * getFilteredContent
     *
     * Get the filtered content
     * Applies the WP content filter to output blocks, etc
     * Also uses str_replace to fix issue with read more (https://core.trac.wordpress.org/ticket/46288)
     *
     * @param String $content
     *
     * @return string
     */
    public function getFilteredContent(string $content): string
    {
        return apply_filters('the_content', str_replace('<!-- /wp:more -->', '<!-- /more -->', $content));
    }

    /**
     * getActiveTags
     *
     * Return active tags for this post type
     *
     * @return array
     */
    public function getActiveTags(): array
    {
        $tags = [];

        $terms = get_the_terms($this->getId(), 'post_tag');

        if ($terms) {
            foreach (get_the_terms($this->getId(), 'post_tag') as $tag) {
                $tags[] = $tag;
            }

            return $tags;
        }

        return [];
    }

    /**
     * getActiveTagIds
     *
     * Return active tag ids for this post type
     *
     * @return array
     */
    public function getActiveTagIds(): array
    {
        $tagIds = [];

        foreach (get_the_terms($this->getId(), 'post_tag') as $tag) {
            $tagIds[] = $tag->term_id;
        }

        return $tagIds;
    }

    /**
     * getMetaProperties
     *
     * Get all the properties of the Custom Post Type that have been tagged in the docblock with "@meta".
     * By tagging properties in this way, the framework will automatically register them with Wordpress
     * and store the data they contain in the "wp_postmeta" table.
     *
     * @return ReflectionProperty[]
     *
     * @throws ReflectionException
     */
    private static function getMetaProperties(): array
    {
        $properties = self::getProperties();

        return array_filter(
            $properties,
            function (ReflectionProperty $property) {
                $comment = $property->getDocComment();
                // Look for whether the property @var declaration contains "@meta"
                preg_match('#@meta #', $comment, $matches);

                return ! isset($matches[0]);
            }
        );
    }

    /**
     * getProperties
     *
     * Get all the properties defined on the class.
     *
     * @return ReflectionProperty[]
     *
     * @throws ReflectionException
     */
    private static function getProperties(): array
    {
        return (new ReflectionClass(get_called_class()))->getProperties(
            ReflectionProperty::IS_PROTECTED | ReflectionProperty::IS_PUBLIC
        );
    }

    /**
     * getClassName
     *
     * Get the name of the Custom Post Type class
     *
     * @return string
     */
    private static function getClassName(): string
    {
        $class = get_called_class();
        $finalNamespaceSeparator = strrpos($class, '\\');

        return ($finalNamespaceSeparator) ? substr($class, $finalNamespaceSeparator + 1) : $class;
    }

    /**
     * getPropertyIsSingle
     *
     * Work out whether the class property represents a single item of data or an array of data.
     * It does this by inspecting the property docblock and seeing if the "@var" declaration ends in "[]".
     * For instance, "@var int[]" or "@var string[]" would be treated as an array or integers, or an array
     * of strings respectively. This is as per standard PHP docblock conventions.
     *
     * @param ReflectionProperty $property
     *
     * @return bool
     */
    private static function getPropertyIsSingle(ReflectionProperty $property): bool
    {
        $comment = $property->getDocComment();
        // Look for whether the @var declaration ends in "[]"
        preg_match('#@var ([a-z]+)\[\]?#', $comment, $matches);

        return ! isset($matches[1]);
    }

    /**
     * getPropertyType
     *
     * Converts standard PHPDoc primitive types to their Wordpress equivalents.
     *
     * @param ReflectionProperty $property
     *
     * @return string
     */
    private static function getPropertyType(ReflectionProperty $property): string
    {
        $comment = $property->getDocComment();
        preg_match('#@var ([a-z]+)?#', $comment, $matches);

        $nativeType = $matches[1] ?? 'string';
        $mapping = [
            'string' => 'string',
            'int' => 'integer',
            'integer' => 'integer',
            'float' => 'number',
            'bool' => 'boolean',
            'boolean' => 'boolean',
        ];

        return $mapping[$nativeType];
    }
}
