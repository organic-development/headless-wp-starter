<?php
/**
 * OrganicFramework
 */
namespace OrganicFramework;

use OrganicFramework\Controllers\CustomPostType;
use OrganicFramework\Controllers\MainController;
use OrganicFramework\Controllers\Settings;
use OrganicFramework\Interfaces\ApiRouteInterface;
use OrganicFramework\Interfaces\BlockRendererInterface;
use OrganicFramework\Interfaces\CustomPostTypeInterface;

/**
 *
 * This class provides the main methods for bootstrapping a plugin using this framework.
 *
 * @package OrganicFramework
 */
class Framework
{
    /**
     * @var CustomPostTypeInterface[] Any registered custom post types
     */
    private $postTypes = [];

    /**
     * @var string Name of the calling plugin directory
     */
    private $pluginDirName;

    /**
     * @var string[] Registered block names
     */
    private $blockNames = [];

    /**
     * @var string The root namespace for the plugin
     */
    private $namespace;

    /**
     * __construct
     *
     * @param string $pluginDirName    The name of your plugin directory
     * @param string $namespace        The root namespace of your plugin, eg. 'MyWebsite'
     * @param string $namespaceRootDir The directory that you wish to register as the PSR-4 namespace root
     */
    public function __construct(string $pluginDirName, string $namespace, string $namespaceRootDir)
    {
        $this->namespace = $namespace;
        $this->pluginDirName = $pluginDirName;
        Autoloader::registerNamespace($namespace, $namespaceRootDir);
        new Settings();
    }

    /**
     * registerCustomPostTypeDirectory
     *
     * Register all the custom post types contained in a particular directory
     *
     * @param string $directory
     */
    public function registerCustomPostTypeDirectory(string $directory)
    {
        $dir = rtrim($directory, '/');
        foreach (glob($dir.'/*.php') as $path) {
            // Trim the file extension off
            $className = str_replace('.php', '', basename($path));
            // Prefix with the namespace
            $namespacedClassName = '\\'.$this->namespace.'\\CustomPostTypes\\'.$className;
            // Create a new instance of the custom post type class
            $postType = new $namespacedClassName();
            // Register the custom post type (will automatically check it implements the correct interface)
            CustomPostType::register($postType);
            $this->postTypes[] = $postType;
        }
    }

    /**
     * registerEditorCss
     *
     * Register a CSS file to be loaded whenever editing in the Admin Area
     *
     * @param string $cssFile File name relative to the calling plugin's directory
     */
    public function registerEditorCss(string $cssFile)
    {
        add_action(
            'admin_enqueue_scripts',
            function () use ($cssFile) {
                wp_enqueue_style(
                    IF_PLUGIN_SLUG.'-editor-css',
                    $this->assetUrl($cssFile),
                    [],
                    $this->assetModificationTime($cssFile)
                );
            }
        );
    }

    /**
     * registerFrontEndCss
     *
     * Register a CSS file to style blocks when they appear on the front end
     *
     * @param string $cssFile File name relative to the calling plugin's directory
     */
    public function registerFrontEndCss(string $cssFile)
    {
        add_action(
            'wp_enqueue_scripts',
            function () use ($cssFile) {
                wp_enqueue_style(
                    IF_PLUGIN_SLUG.'-css',
                    $this->assetUrl($cssFile),
                    [],
                    $this->assetModificationTime($cssFile)
                );
            }
        );
    }

    /**
     * registerBlocksJs
     *
     * Register a single JS file containing any custom blocks code that your plugin uses. Only a single JS file
     * is passed as it's assumed you will be using a build tool to concatenate multiple blocks into a single file.
     *
     * @param string $jsFile       File name relative to the calling plugin's directory
     * @param array  $dependencies An array of any JS component dependencies required by the contained blocks
     */
    public function registerBlocksJs(string $jsFile, array $dependencies = ['wp-blocks'])
    {
        add_action(
            'admin_enqueue_scripts',
            function () use ($jsFile, $dependencies) {
                wp_enqueue_script(
                    IF_PLUGIN_SLUG.'-editor-script',
                    $this->assetUrl($jsFile),
                    $dependencies,
                    $this->assetModificationTime($jsFile)
                );
            }
        );
    }

    /**
     * registerBlockDirectory
     *
     * Register any custom blocks used by your plugin by providing the root directory. The framework
     * will automatically traverse the directory, picking up on subdirectory names, and registering
     * the contained blocks with Wordpress.
     *
     * @param string $blockDirectory The full path to your blocks directory
     */
    public function registerBlockDirectory(string $blockDirectory)
    {
        $blockDirectory = rtrim($blockDirectory, '/');
        $directories = glob($blockDirectory.'/*', GLOB_ONLYDIR);
        $this->blockNames = array_map(
            function (string $fullPath) {
                return basename($fullPath);
            },
            $directories
        );

        foreach ($this->blockNames as $blockName) {
            $renderCallback = null;

            // Register a front-end block renderer, if one exists
            $className = '\\'.$this->namespace.'\\Blocks\\'.$blockName.'\\Renderer';
            if (class_exists($className)) {
                // Check that the Renderer class implements the appropriate interface
                // (so we can guarantee that the 'render()' method exists on it).
                if (!in_array(BlockRendererInterface::class, class_implements($className))) {
                    die(sprintf('Block renderer %s must implement %s', $className, BlockRendererInterface::class));
                }

                $renderCallback = function ($attrs, $content = null) use ($className) {

                    /** @var BlockRendererInterface $className */

                    return $className::render($attrs, $content);
                };
            }

            // Register meta fields if definition exists
            $filename = $blockDirectory.'/'.$blockName.'/meta.php';
            if (file_exists($filename)) {
                /** @noinspection PhpIncludeInspection */
                $meta = require $filename;
                foreach ($meta as $field => $options) {
                    add_action(
                        'init',
                        function () use ($field, $options) {
                            register_meta(
                                'post',
                                $field,
                                $options
                            );
                        }
                    );
                }
            }

            register_block_type(
                $this->pluginDirName.'/'.strtolower($blockName),
                [
                    'editor_script' => IF_PLUGIN_SLUG.'-editor-script',
                    'editor_style' => IF_PLUGIN_SLUG.'-editor-css',
                    'style' => IF_PLUGIN_SLUG.'-css',
                    'render_callback' => $renderCallback,
                ]
            );
        }
    }

    /**
     * run
     *
     * Kick off the main framework process
     */
    public function run()
    {
        $controller = new MainController($this->postTypes, $this->blockNames);
        $controller->run();
    }

    /**
     * whitelistBlocks
     *
     * Only allow certain core Wordpress blocks to be used for this site
     *
     * @param array $excludeBlocks
     */
    public function whitelistBlocks($excludeBlocks = [])
    {
        $namespacedBlocks = array_map(
            function ($blockName) use ($excludeBlocks) {
                $blockPath = $this->pluginDirName.'/'.strtolower($blockName);

                return ( ! in_array($blockPath, $excludeBlocks)) ? $blockPath : null;
            },
            $this->blockNames
        );
        $allowedBlocks = array_merge($namespacedBlocks, ALLOWED_CORE_BLOCKS);

        add_filter(
            'allowed_block_types',
            function () use ($allowedBlocks) {
                return $allowedBlocks;
            },
            5
        );
    }

    /**
     * registerBlockCategories
     *
     * Register custom block categories that can be used to group blocks.
     *
     * @param array $blockCategoryNames
     */
    public function registerBlockCategories(array $blockCategoryNames)
    {
        add_filter(
            'block_categories',
            function ($categories) use ($blockCategoryNames) {
                $blockCategories = [];
                foreach ($blockCategoryNames as $blockCategoryName) {
                    $blockCategories[] = [
                        'slug' => $blockCategoryName,
                        'title' => __(ucwords(str_replace('-', ' ', $blockCategoryName)), IF_PLUGIN_SLUG),
                    ];
                }

                return array_merge(
                    $categories,
                    $blockCategories
                );
            },
            10,
            2
        );
    }

    /**
     * registerApiDirectory
     *
     * Register a directory containing one or more API route definitions. The framework will automatically
     * scan this directory and register the routes/endpoints with Wordpress.
     *
     * @param string $directory The path to the directory containing the defined API routes
     */
    public function registerApiDirectory(string $directory)
    {
        $dir = rtrim($directory, '/');
        foreach (glob($dir.'/*.php') as $path) {
            // Trim the file extension off
            $className = str_replace('.php', '', basename($path));
            // Prefix with the namespace
            $namespacedClassName = '\\'.$this->namespace.'\\ApiRoutes\\'.$className;

            // Check the route class implements the appropriate interface
            if (!in_array(ApiRouteInterface::class, class_implements($namespacedClassName))) {
                die(sprintf('API Route %s must implement %s', $className, ApiRouteInterface::class));
            }

            // Create a new instance of the custom post type class
            add_action(
                'rest_api_init',
                function () use ($namespacedClassName) {
                    /** @var ApiRouteInterface $namespacedClassName */
                    register_rest_route(
                        $this->pluginDirName,
                        '/'.$namespacedClassName::getName(),
                        [
                            'methods' => $namespacedClassName::getMethod(),
                            'callback' => function () use ($namespacedClassName) {
                                return $namespacedClassName::run();
                            },
                            'permission_callback' => function () use ($namespacedClassName) {
                                return $namespacedClassName::userHasPermission();
                            },
                        ]
                    );
                }
            );
        }
    }

    /**
     * assetUrl
     *
     * Get the URL for an asset
     *
     * @param string $relativeAssetPath File name relative to the calling plugin's directory
     *
     * @return string
     */
    private function assetUrl(string $relativeAssetPath): string
    {
        return plugins_url($this->pluginDirName.DIRECTORY_SEPARATOR.$relativeAssetPath);
    }

    /**
     * assetModificationTime
     *
     * Get the last modified timestamp for an asset
     *
     * @param string $cssFile File name relative to the calling plugin's directory
     *
     * @return int
     */
    private function assetModificationTime(string $cssFile): int
    {
        return filemtime(IF_PLUGIN_ROOT.'..'.DIRECTORY_SEPARATOR.$this->pluginDirName.DIRECTORY_SEPARATOR.$cssFile);
    }
}
