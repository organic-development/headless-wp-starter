<?php
/**
 * Settings view
 */
?>
<div class="wrap">

    <h2><?php echo IF_PLUGIN_TITLE; ?></h2>

    <form method="post" action="options.php">
        <?php

        // Get settings fields
        settings_fields(IF_PLUGIN_SLUG);

        // Settings sections
        do_settings_sections(IF_PLUGIN_SLUG);

        // Submit button
        submit_button();

        ?>
    </form>

</div>