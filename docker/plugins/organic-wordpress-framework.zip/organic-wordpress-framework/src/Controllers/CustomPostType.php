<?php
/**
 * OrganicFramework\Controllers
 */
namespace OrganicFramework\Controllers;

use OrganicFramework\Interfaces\CustomPostTypeInterface;
use OrganicFramework\Models\MetaBox;
use WP_Customize_Media_Control;
use WP_Post;
use WP_Query;

/**
 * This class acts as a collection of static functions for registering and configuring individual post types.
 * It abstracts away some of the Wordpress config in a more friendly OOP fashion.
 *
 * @package OrganicFramework\Controllers
 */
class CustomPostType
{
    /**
     * register
     *
     * This is the only publicly-exposed method in this class and provides the main gateway for
     * registering a new Custom Post Type with Wordpress. To create a new Custom Post Type, create
     * a class that implements CustomPostTypeInterface and pass it to this method.
     *
     * @param CustomPostTypeInterface $postType
     */
    public static function register(CustomPostTypeInterface $postType)
    {
        self::registerMetaFields($postType);

        self::registerMetaBoxes($postType);

        self::registerCustomPostType($postType);

        self::configureResultsColumns($postType);

        self::configureResultsOrder($postType);

        self::configureBlocks($postType);

        self::initCustomiserOptions($postType);

        self::configureMenuOrderColumn($postType);
    }

    /**
     * registerMetaFields
     *
     * This method provides a way of registering all the meta fields needed by a Custom Post Type.
     * These are typically discrete pieces of data that you want to store against your Custom Post Type
     * that aren't covered by Wordpress' core fields (like Title, Content, Excerpt, etc).
     *
     * An example for an Office might be: city and postcode. These get stored in the Wordpress table
     * "wp_postmeta".
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function registerMetaFields(CustomPostTypeInterface $postType)
    {
        foreach ($postType->getMetaFields() as $field => $options) {
            add_action(
                'init',
                function () use ($field, $options) {
                    register_meta(
                        'post',
                        $field,
                        $options
                    );
                }
            );
        }
    }

    /**
     * registerMetaBoxes
     *
     * Though typically not used any more (Wordpress meta boxes have effectively been deprecated in favour
     * of Gutenberg blocks), this method can be used to register any old-style meta boxes for a Custom Post Type.
     *
     * These appear at the bottom of the post edit screen as a series of form fields. Currently a fairly
     * limited number of different input types are available - see \OrganicFramework\Models\MetaBox::html for
     * more details.
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function registerMetaBoxes(CustomPostTypeInterface $postType)
    {
        // MetaBox model
        $metaBox = new MetaBox;

        // Loop through fields in the parent model
        foreach ($postType->getFields() as $fieldID => $field) {

            // Add meta box for field
            $metaBox->add(
                $fieldID,
                $field['fieldTitle'],
                $postType->getKey(),
                $field['fieldType'],
                $field['options'] ?? []
            );
        }

        // Run the hook
        $metaBox->hook();
    }

    /**
     * registerCustomPostType
     *
     * Register this custom post type with Wordpress
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function registerCustomPostType(CustomPostTypeInterface $postType)
    {
        // Hook on init
        add_action(
            'init',
            function () use ($postType) {
                /**
                 * Wordpress standard option keys.
                 * @see https://codex.wordpress.org/Function_Reference/register_post_type
                 */
                $defaultOptions = [
                    'show_in_menu' => true,
                    'show_in_rest' => true,
                    'public' => true,
                    'labels' => [
                        'name' => __($postType->getNamePlural()),
                        'singular_name' => __($postType->getNameSingular()),
                        'add_new_item' => 'Add '.__($postType->getNameSingular()),
                        'edit_item' => 'Edit '.__($postType->getNameSingular()),
                    ],
                    'supports' => [
                        'title',
                        'editor',
                        'custom-fields', // Required for blocks to be able to save to post meta
                    ],
                ];
                $options = array_replace_recursive($defaultOptions, $postType->getOptions());
                register_post_type($postType->getKey(), $options);
            }
        );

    }

    /**
     * configureResultsColumns
     *
     * Allow meta fields defined by the custom post types to be shown as columns on the list pages of the admin area.
     * Relies on the field to have a config entry in the format:
     * [
     *   'column' => [
     *     'before' => string - name of column to put this one before,
     *     'view' => callable(string $column, int $post_id) - will return what content you want to show in the column.
     *   ]
     * ]
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function configureResultsColumns(CustomPostTypeInterface $postType)
    {
        // Look for any fields that have asked to show one of the meta columns on the list page
        foreach ($postType->getColumns() as $fieldKey => $config) {
            add_filter(
                'manage_'.$postType->getKey().'_posts_columns',
                function ($columns) use ($config, $fieldKey) {
                    $newColumns = [];
                    $move = $fieldKey; // what to move
                    $before = $config['before']; // move before this
                    foreach ($columns as $key => $value) {
                        if ($key == $before) {
                            $newColumns[$move] = $config['fieldTitle'];
                        }
                        $newColumns[$key] = $value;
                    }

                    return $newColumns;
                }
            );

            add_action(
                'manage_'.$postType->getKey().'_posts_custom_column',
                function ($column, $post_id) use ($config, $fieldKey) {
                    if ($column === $fieldKey) {
                        echo $config['view']($column, $post_id);
                    }
                },
                10,
                2
            );
        }
    }

    /**
     * configureResultsOrder
     *
     * Set the order of results on the admin list page for a Custom Post Type - ie. typically by a
     * specific column or set of columns.
     *
     * @param CustomPostTypeInterface $postType
     *
     * @see https://codex.wordpress.org/Class_Reference/WP_Query
     *
     * @see self::getResultsOrder()
     */
    private static function configureResultsOrder(CustomPostTypeInterface $postType)
    {
        if ($orderClauses = $postType->getResultsOrder()) {
            add_filter(
                'pre_get_posts',
                function (WP_Query $query) use ($orderClauses, $postType) {
                    // Check we're in the Admin Area
                    if ($query->is_admin) {
                        // Only apply this filter to the current post type
                        if ($query->get('post_type') === $postType->getKey()) {
                            $metaQuery = [];
                            $orderBy = [];
                            foreach ($orderClauses as $column => $options) {
                                $clause = $column.'_clause';
                                $orderBy[$clause] = $options['direction'];
                                $metaQuery[] = [
                                    $clause => [
                                        'key' => $column,
                                        'type' => $options['type'],
                                    ],
                                ];
                            }
                            $query->set('meta_query', $metaQuery);
                            $query->set('orderby', $orderBy);
                        }
                    }

                    return $query;
                }
            );
        }
    }

    /**
     * configureBlocks
     *
     * Configure which blocks can appear on the add/edit screen for this custom post type. This provides a
     * mechanism for whitelisting only those blocks which make sense for an editor to see on this
     * particular post type (and what the corresponding front-end templates can handle).
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function configureBlocks(CustomPostTypeInterface $postType)
    {
        add_filter(
            'allowed_block_types',
            function ($allowedBlockTypes, WP_Post $post) use ($postType) {
                $allowedBlocks = $postType->allowedBlocks();
                if ( ! empty($allowedBlocks) && $post->post_type === $postType->getKey()) {
                    return array_merge(ALLOWED_CORE_BLOCKS, $allowedBlocks);
                } else {
                    return $allowedBlockTypes;
                }
            },
            10,
            2
        );
    }

    /**
     * initCustomiserOptions
     *
     * Set up the fields within WP Customiser
     * Shows the options for intro text and image when editing an archive page
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function initCustomiserOptions(CustomPostTypeInterface $postType)
    {

        if ($postType->useCustomiser()) {

            add_action(
                'customize_register',
                function ($wp_customize) use ($postType) {
                    $panelName = $postType->getKey().'_options';
                    $sectionName = $postType->getKey();
                    $wp_customize->add_panel(
                        $panelName,
                        [
                            'priority' => 30,
                            'capability' => 'edit_theme_options',
                            'theme_supports' => '',
                            'title' => esc_html__($postType->getNameSingular().' Options', $postType->getKey()),
                            'description' => esc_html__(
                                'Panel to update '.$postType->getNameSingular().' options',
                                $postType->getKey()
                            ),
                        ]
                    );
                    $wp_customize->add_section(
                        $sectionName,
                        [
                            'priority' => 10,
                            'panel' => $panelName,
                            'capability' => 'edit_theme_options',
                            'title' => esc_html__('Listing Page', $postType->getKey()),
                            'description' => esc_html__('Panel to update the listing options', $postType->getKey()),
                            'description_hidden' => false,
                        ]
                    );
                    $wp_customize->add_setting(
                        $sectionName.'_intro_text',
                        [
                            'default' => '',
                            'transport' => 'refresh',
                            'sanitize_callback' => 'wp_kses_stripslashes',
                        ]
                    );

                    $wp_customize->add_control(
                        $sectionName.'_intro_text',
                        [
                            'type' => 'textarea',
                            'label' => esc_html__('Page Intro Text', $postType->getKey()),
                            'section' => $sectionName,
                        ]
                    );
                    $wp_customize->add_setting(
                        $sectionName.'_hero_image',
                        [
                            'default' => '',
                            'transport' => 'refresh',
                            'sanitize_callback' => 'absint',
                        ]
                    );

                    $wp_customize->add_control(
                        new WP_Customize_Media_Control(
                            $wp_customize, $sectionName.'_hero_image',
                            [
                                'label' => __('Header Background Image'),
                                'description' => esc_html__('Select an image for the section header'),
                                'section' => $sectionName,
                                'mime_type' => 'image',
                                'button_labels' => [ // Optional.
                                    'select' => __('Select Image'),
                                    'change' => __('Change Image'),
                                    'remove' => __('Remove'),
                                    'default' => __('Default'),
                                    'placeholder' => __('No image selected'),
                                    'frame_title' => __('Select Image'),
                                    'frame_button' => __('Choose Image'),
                                ],
                            ]
                        )
                    );
                }
            );

        }
    }

    /**
     * configureMenuOrderColumn
     *
     * Show the 'menu order' column on the listing page for the post type. This can be used by plugins
     * such as "Simple Page Ordering" to provide a method for manually reordering posts. Typically this is
     * used where an editor might need to define an arbitrary order of priority for a series of posts, rather
     * than relying on a default alphabetical or chronological order.
     *
     * @param CustomPostTypeInterface $postType
     */
    private static function configureMenuOrderColumn(CustomPostTypeInterface $postType)
    {
        // If the 'page-attributes' option is supported
        if (in_array('page-attributes', self::getOption($postType, 'supports'))) {
            add_action(
                'manage_edit-'.$postType->getKey().'_columns',
                function ($columns) {
                    $columns['menu_order'] = "Order";

                    return $columns;
                }
            );

            add_action(
                'manage_'.$postType->getKey().'_posts_custom_column',
                function ($name) {
                    global $post;

                    switch ($name) {
                        case 'menu_order':
                            $order = $post->menu_order;
                            echo $order;
                            break;
                        default:
                            break;
                    }
                }
            );

            add_filter(
                'manage_edit-'.$postType->getKey().'_sortable_columns',
                function ($columns) {
                    $columns['menu_order'] = 'menu_order';

                    return $columns;
                }
            );
        }
    }

    /**
     * getOption
     *
     * Get a single option's value, defaulting to the supplied value if it isn't configured for this post type.
     *
     * @param CustomPostTypeInterface $postType
     * @param string $optionName
     * @param bool $default
     *
     * @return bool|mixed
     */
    private static function getOption(CustomPostTypeInterface $postType, string $optionName, $default = false)
    {
        $options = $postType->getOptions();

        return $options[$optionName] ?? $default;
    }
}
