<?php
/**
 * OrganicFramework\Controllers
 */
namespace OrganicFramework\Controllers;

use OrganicFramework\Interfaces\CustomPostTypeInterface;
use OrganicFramework\Models\Post;

/**
 * Provides the request-level bootstrapping for the framework. This means handling shortcodes, post data from
 * metaboxes, and custom error notifications.
 *
 * @package OrganicFramework\Controllers
 */
class MainController
{
    /**
     * An internal store of any post types that have been registered, indexed by post type name (key).
     *
     * @var CustomPostTypeInterface[]
     */
    private $postTypes;

    /**
     * @var array The list of block names that have been registered
     */
    private $blocks = [];

    /**
     * __construct
     *
     * @param CustomPostTypeInterface[] $postTypes
     * @param array $blocks The list of block names to register
     */
    public function __construct(array $postTypes, array $blocks = [])
    {
        // Index the post types by key
        foreach ($postTypes as $postType) {
            $this->postTypes[$postType->getKey()] = $postType;
        }
        $this->blocks = $blocks;
    }

    /**
     * doInclude
     *
     * Renders a PHP template file given an array of data. Typically used to render a HTML template with some
     * dynamic data.
     *
     * Uses output buffering to return the rendered content where requested.
     *
     * @param string $filePath The full path to the included file
     * @param bool $return If true, output will be returned, rather than echo
     * @param array $args Array of named arguments
     *
     * @return false|string
     */
    public static function doInclude(string $filePath = '', bool $return = true, $args = [])
    {
        // Extract the arguments from the array
        if ($args) {
            extract($args);
        }

        // Start the output buffer
        ob_start();

        // Include the file
        /** @noinspection PhpIncludeInspection */
        require $filePath;

        // Return or echo the output
        if ($return) {
            return ob_get_clean();
        } else {
            echo ob_get_clean();
        }

        return false;
    }

    /**
     * getSettingValue
     *
     * Get the value of a WP setting. Returns false if setting key doesn't exist
     *
     * @param String $key The key of the setting value to get
     *
     * @return String|Boolean
     *
     */
    public static function getSettingValue($key = '')
    {
        return get_option($key);
    }

    /**
     * run
     *
     * Kick off the main framework process
     */
    public function run()
    {
        // Handle any POSTed incoming meta data
        $this->processMetaBoxes();

        // Show any validation notifications to the admin user
        self::showNotifications();

        // Temporary, for testing short codes
        self::handleModuleShortCodes();
    }

    /**
     * processMetaBoxes
     *
     * Deal with any incoming POST meta data submitted as part of adding or editing a custom post type in the
     * Admin Area.
     */
    private function processMetaBoxes()
    {
        if ( ! empty($_POST['metaboxes'])) {

            $postID = (int)$_POST['post_ID'];
            $key = get_post_type($postID);
            if (in_array($key, array_keys($this->postTypes))) {
                $postType = $this->postTypes[$key];
                $post = new Post($postType, $postID, $_POST['metaboxes']);

                // Hook to save the data
                add_action('save_post', [$post, 'save']);

                add_action('pre_post_update', [$post, 'validate'], 10, 2);
            }
        }
    }

    /**
     * showNotifications
     *
     * Show any notifications triggered by our custom post type validation routines.
     */
    private static function showNotifications()
    {
        add_action(
            'admin_notices',
            function () {
                $notifications = get_option('my_notifications');
                if ( ! empty($notifications)) {
                    $errors = json_decode($notifications);
                    echo '<div class="error notice">';
                    foreach ($errors as $error) {
                        echo '<p>'.$error.'</p>';
                    }
                    echo '</div>';

                    // Let's reset the notification
                    update_option('my_notifications', false);
                }
            }
        );
    }

    /**
     * handleModuleShortCodes
     *
     * Handle requests that should be processed by our modules. Typically these will be POST requests from forms
     * contained in shortcode module output.
     *
     * This also has the benefit of allowing testing of shortcodes, without needing a functioning theme
     * by appending a shortcode parameter to the querystring, along with an attrs array parameter, where required.
     */
    private static function handleModuleShortCodes()
    {
        if ( ! empty($_GET['shortcode'])) {
            $shortCode = $_GET['shortcode'];
            $attrs = '';
            foreach (($_GET['attrs'] ?? []) as $key => $value) {
                $attrs .= ' '.$key.'="'.$value.'"';
            }

            echo do_shortcode('['.$shortCode.' '.$attrs.']');
        }
    }
}
