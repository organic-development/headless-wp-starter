<?php
/**
 * OrganicFramework\Controllers
 */
namespace OrganicFramework\Controllers;

/**
 *
 * Provides a way to register a settings page for our plugin.
 *
 * @package OrganicFramework\Controllers
 */
class Settings
{
    /**
     * __construct
     *
     */
    public function __construct()
    {
        // Hook to add settings page to admin menu
        add_action('admin_menu', [$this, 'registerSettingsPage']);

        // Hook to setup sections
        add_action('admin_init', [$this, 'registerSections']);

        // Hook to register fields
        add_action('admin_init', [$this, 'registerFields']);
    }

    /**
     * registerSettingsPage
     *
     * Register settings page - adds a new menu item.
     */
    public function registerSettingsPage()
    {
        // Add the menu item and page
        add_menu_page(
            'Framework Settings',
            IF_PLUGIN_TITLE,
            'manage_options',
            IF_PLUGIN_SLUG,
            [$this, 'showSettingsPage'],
            'dashicons-admin-plugins',
            100
        );
    }

    /**
     * showSettingsPage
     *
     * Show the settings page using the 'doInclude' method from the 'MainController' class
     */
    public function showSettingsPage()
    {
        // Include the view
        MainController::doInclude(IF_VIEWS_FOLDER.'/Settings/settings-page.php', false);
    }

    /**
     * registerSections
     *
     * Register the sections for the settings page
     */
    public function registerSections()
    {
        // Add section for general settings
        add_settings_section(
            'general_section',
            'General',
            [$this, 'showSections'],
            IF_PLUGIN_SLUG
        );
    }

    /**
     * showSections
     *
     * Show the sections. Just echoes a title
     */
    public function showSections()
    {
        echo 'Settings specific to the website';
    }

    /**
     * registerFields
     *
     * Add & register the settings fields. Needs work to separate indivdiual settings into a separate file / method
     */
    public function registerFields()
    {
        // Add Checkbox for reviews. TODO: move this somewhere else!
        add_settings_field(
            IF_PLUGIN_SLUG.'_show-reviews',
            'Show Reviews',
            function () {
                $this->showInput(IF_PLUGIN_SLUG.'_show-reviews');
            },
            IF_PLUGIN_SLUG,
            'general_section'
        );

        // Register the setting
        register_setting(IF_PLUGIN_SLUG, IF_PLUGIN_SLUG.'_show-reviews');
    }

    /**
     * showInput
     *
     * Show a form input field for a given option.
     *
     * @param string $optionName
     */
    public function showInput(string $optionName)
    {
        $checkedAttribute = ((int) get_option($optionName) === 1) ? 'checked="checked"' : '';
        echo '<input type="checkbox" name="'.$optionName.'" value="1" '.$checkedAttribute.'>';
    }
}
