<?php
/**
 * OrganicFramework\Interfaces
 */
namespace OrganicFramework\Interfaces;

/**
 * Interface BlockRendererInterface
 *
 * A Gutenberg block can be rendered at the point of saving in the Admin Area (and saved to the database as HTML),
 * or alternatively saved as JSON and rendered at request time server-side.
 * This interface is used where the latter scenario is required.
 *
 * @package OrganicFramework\Interfaces
 */
interface BlockRendererInterface
{
    /**
     * Handle outputting the front end module this block appears in a post's content
     *
     * @param array  $attrs   The attributes from the block
     * @param string $content The block content
     *
     * @return string
     */
    public static function render(array $attrs, string $content = ''): string;
}
