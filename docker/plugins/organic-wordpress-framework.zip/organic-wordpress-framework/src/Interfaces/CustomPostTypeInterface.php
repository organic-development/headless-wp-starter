<?php
/**
 * OrganicFramework\Interfaces
 */
namespace OrganicFramework\Interfaces;

/**
 * Interface CustomPostTypeInterface
 *
 * Methods for retrieivng data for a custom post type. Functionality is defined in the AbstractCustomPostType
 *
 * @package OrganicFramework\Interfaces
 */
interface CustomPostTypeInterface
{
    /**
     * __construct
     *
     * The Wordpress slug for this Custom Post Type
     *
     * @param int $postId
     */
    public function __construct(int $postId = null);

    /**
     * getKey
     *
     * The Wordpress slug for this Custom Post Type
     *
     * @return string
     */
    public static function getKey(): string;

    /**
     * getNameSingular
     *
     * The singular name for this Custom Post Type. Eg. "Office", "Person", "Job"
     *
     * @return string
     */
    public static function getNameSingular(): string;

    /**
     * getNamePlural
     *
     * The plural name for this Custom Post Type. Eg. "Offices", "People", "Jobs"
     *
     * @return string
     */
    public static function getNamePlural(): string;

    /**
     * getMetaFields
     *
     * Register post meta fields with Wordpress.
     *
     * The array should be in the format:
     * [
     *   'ClassName.PropertyName' => [
     *     'type' => 'integer' // one of WP's accepted types ('string', 'boolean', 'integer', and 'number')
     *     'show_in_rest' => true // true or false
     *     'single' => true // true or false
     *   ]
     * ]
     *
     * @return array
     */
    public static function getMetaFields(): array;

    /**
     * getFields
     *
     * Configure all the meta fields that should appear for this post type.
     * The returned array should use the following format:
     * [
     *   'field-name' => [
     *     'fieldTitle' => 'Field Label',
     *     'fieldType' => 'select', // eg. The HTML form element to use 'select', 'number'
     *     'required' => true, // whether to validate that the field is populated
     *     'saveValue' => true, // whether to save the value to the database
     *     'options' => $options, // a key-value array of options that can be used for form elements (select, radio, etc)
     *     'column' => [
     *       'before' => 'another-column', // name of column to position this one before
     *       'view' => callable // a callable that will determine what value to show in the column
     *     ]
     *   'field-name-2' ...etc
     * ]
     *
     * @return array
     *
     * @see MetaBox::html()
     */
    public static function getFields(): array;

    /**
     * getColumns
     *
     * Configure any meta fields that should appear as columns on the list page in the Admin Area:
     * [
     *   'field-name' => [
     *     'column' => [
     *       'before' => 'another-column', // name of column to position this one before
     *       'fieldTitle' => 'Column Heading', // will appear as the column header
     *       'view' => callable // a callable that will determine what value to show in the column
     *     ]
     *   'field-name-2' ...etc
     * ]
     *
     * @return array
     */
    public static function getColumns(): array;

    /**
     * getOptions
     *
     * Configure all the options for this post type.
     * These are expected to use the same naming as the keys passed to WP's register_post_type function.
     *
     * @see https://codex.wordpress.org/Function_Reference/register_post_type
     *
     * @return array
     */
    public static function getOptions(): array;

    /**
     * getResultsOrder
     *
     * Define the order in which posts are displayed on the admin list page.
     * @see https://codex.wordpress.org/Class_Reference/WP_Meta_Query
     *
     * The array should follow the format:
     *   [
     *     'column-name' => [
     *       'type' => 'TYPE' // a WP-compatible type - eg. 'NUMERIC'
     *       'direction' => 'DIRECTION' // either 'ASC' or 'DESC'
     *     ]
     *     'column-two' ...etc
     *   ]
     * @return array
     */
    public static function getResultsOrder(): array;

    /**
     * allowedBlocks
     *
     * Configure which blocks should be available for this custom post type.
     * Return 'true' to enable all, 'false' to disable all, and an array for specific blocks.
     *
     * @return bool|array
     */
    public static function allowedBlocks();
}
