<?php
/**
 * OrganicFramework\Interfaces
 */
namespace OrganicFramework\Interfaces;

use WP_REST_Response;

/**
 * Interface ApiRouteInterface
 *
 * This interface ensures that any custom API routes we register with Wordpress are done in a standardised
 * fashion. Custom API routes should only be use where Wordpress' default API routes that it provides for
 * custom post types is not sufficient.
 *
 * For instance, Wordpress will by default provide "/wp-json/wp/v2/{custom-post-type}" as a fully working endpoint
 * by default. Custom API endpoints are usually only needed when the data needs to be provided in a substantially
 * different format, or where data from various relationships needs to be automatically resolved.
 *
 * @package OrganicFramework\Interfaces
 */
interface ApiRouteInterface
{
    /**
     * getName
     *
     * @return string The URL segment for this route - eg. 'products'
     */
    public static function getName(): string;

    /**
     * getMethod
     *
     * @return string The HTTP method for this route - eg. 'GET'
     */
    public static function getMethod(): string;

    /**
     * run
     *
     * @return WP_REST_Response What to actually output when this route is called.
     */
    public static function run(): WP_REST_Response;

    /**
     * userHasPermission
     *
     * Typically will use something like current_user_can('edit_post')
     *
     * @return bool Whether the current user actually has permissions to call this route
     */
    public static function userHasPermission(): bool;
}
