<?php
/**
 * OrganicFramework
 */
namespace OrganicFramework;

use Exception;

/**
 * As Wordpress doesn't provide any PHP autoloading by default, our framework provides a simple method
 * of registering a namespace that should be autoloaded.
 *
 * @package OrganicFramework
 */
class Autoloader
{
    /**
     * registerNamespace
     *
     * Register a custom namespace for a plugin. Any classes within the supplied directory and namespace
     * will then be autoloaded where needed.
     *
     * PSR-4 conventions should be followed when naming classes, namespaces, and directories.
     * @see https://www.php-fig.org/psr/psr-4/
     *
     * @param string $namespace The name of the namespace
     * @param string $dir       The root directory path for the namespace
     */
    public static function registerNamespace(string $namespace, string $dir)
    {
        try {
            // Register a PSR-4 style autoloader for our framework
            spl_autoload_register(
                function ($class) use ($namespace, $dir) {
                    // Check that the requested class is part of our current namespace
                    if (stripos($class, $namespace) === 0) {
                        $filePath = $dir.str_replace(
                            '\\',
                            DIRECTORY_SEPARATOR,
                            substr($class, strlen($namespace))
                        ).'.php';
                        /** @noinspection PhpIncludeInspection */
                        @include($filePath);
                    }
                }
            );
        } catch (Exception $e) {
            echo $e;
        }
    }
}
