<?php
/**
 * OrganicFramework\Models
 */
namespace OrganicFramework\Models;

use WP_Post;

/**
 * Model class to manipulate meta boxes. A meta box is a now-deprecated way of storing custom data
 * for a particular Custom Post Type, and have largely been replaced by Gutenberg blocks.
 *
 * Meta boxes appear below the editor in the Admin Area edit screen.
 *
 * @package OrganicFramework\Models
 */
class MetaBox
{
    /**
     * Array of meta boxes
     */
    protected $metaboxes = [];

    /**
     * hook
     *
     * Hook function
     *
     * Implements the hook to add meta boxes to WP
     */
    public function hook()
    {
        add_action('add_meta_boxes', [$this, 'addAll']);
    }

    /**
     * addAll
     *
     * Adds all of the meta boxes in the array
     *
     */
    public function addAll()
    {
        // Loop through all meta boxes
        foreach ($this->metaboxes as $metabox) {
            add_meta_box(
                $metabox['id'],
                $metabox['title'],
                [$this, 'html'], // Callback
                $metabox['postType'],
                'normal', // Context
                'default', // Priority
                [$metabox['type'], $metabox['options']] // Callback args
            );
        }
    }

    /**
     * add
     *
     * Add a metabox
     *
     * @param String $id
     * @param String $title
     * @param String $postType
     * @param String $type
     * @param array  $options
     *
     */
    public function add(String $id, String $title, String $postType, String $type, array $options = [])
    {
        // Add data to metabox array
        $this->metaboxes[] = [
            'id' => $id,
            'title' => $title,
            'postType' => $postType,
            'type' => $type,
            'options' => $options,
        ];
    }

    /**
     * html
     *
     * Output the HTML form elements for a metabox
     *
     * @access public
     *
     * @param WP_Post $post
     * @param array   $config
     */
    public function html(WP_Post $post, array $config)
    {
        $id = $config['id'];
        $name = 'metaboxes['.$id.']';
        $elementType = $config['args'][0];
        $currentValue = $this->getValue($post->ID, $config['id']);
        $options = $config['args'][1] ?? [];

        // Switch based on field type
        switch ($elementType) {
            case 'checkbox':
                $checkboxes = array_map(
                    function (array $option) use ($currentValue, $name) {
                        $currentValue = empty($currentValue) ? [] : $currentValue;
                        $checkedAttribute = (in_array($option['value'], $currentValue)) ? 'checked="checked"' : '';

                        return '<label><input type="checkbox" name="'.$name.'[]" value="'.$option['value'].'" '.$checkedAttribute.' />'.$option['name'].'</label>';
                    },
                    $options
                );
                echo implode('<br>', $checkboxes);
                break;

            case 'select':
                $optionElements = array_map(
                    function (array $option) use ($currentValue) {
                        $selectedAttribute = ($currentValue === $option['value']) ? 'selected="selected"' : '';

                        return '<option value="'.$option['value'].'" '.$selectedAttribute.'>'.$option['name'].'</option>';
                    },
                    $options
                );
                $selectedAttribute = ($currentValue === '') ? 'selected="selected"' : '';
                echo '<select name="'.$name.'"><option value="" '.$selectedAttribute.'>Please Select...</option>'.implode('', $optionElements).'</select>';
                break;

            default:
                echo '<input type="'.$elementType.'" name="'.$name.'" id="'.$id.'" value="'.$currentValue.'">';
                break;
        }
    }

    /**
     * getValue
     *
     * Get the value of a particular meta item
     *
     * @param Int    $postID
     * @param String $metaBoxKey The meta box ID
     *
     * @return mixed
     */
    public function getValue(Int $postID, String $metaBoxKey)
    {
        return get_post_meta((int) $postID, $metaBoxKey, true);
    }
}
