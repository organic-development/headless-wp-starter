<?php
/**
 * OrganicFramework\Models
 */
namespace OrganicFramework\Models;

use Exception;
use OrganicFramework\Interfaces\CustomPostTypeInterface;
use WP_Post;

/**
 * Provides utility functions relating to retrieval of custom post type data, along with methods to
 * save any related metabox data.
 *
 * @package OrganicFramework\Models
 */
class Post
{
    /**
     * @var CustomPostTypeInterface
     * The post type interface
     */
    private $postType;
    /**
     * @var int
     * The post ID
     */
    private $postID;
    /**
     * @var array
     * An array of data contained in the post
     */
    private $data;

    /**
     * __construct
     *
     * @param CustomPostTypeInterface $postType The post type interface
     * @param int                     $postID   The post ID
     * @param array                   $data     An array of data contained in the post
     */
    public function __construct(CustomPostTypeInterface $postType, int $postID, array $data)
    {
        $this->postType = $postType;
        $this->postID = $postID;
        $this->data = $data;
    }

    /**
     * getAll
     *
     * Utility function to get a collection of populated Custom Post Type instances, for a given criteria.
     * Abstracts away the Wordpress database calls.
     *
     * @param string $postClass The class of the post type
     * @param array  $order     The order in which to return the results
     * @param array  $metaWhere Optional where clause in the form ['key' => 'key', 'value' => 'value']
     *
     * @return CustomPostTypeInterface[]
     */
    public static function getAll(string $postClass, array $order = ['post_date' => 'DESC'], array $metaWhere = []): array
    {
        /** @var CustomPostTypeInterface $postType */
        $postType = new $postClass();
        $args =
            [
                'numberposts' => 1000, // Set a high default (WP only chooses 5 by default)
                'post_type' => $postType::getKey(),
                'orderby' => $order,
            ];
        if ($metaWhere) {
            $args['meta_key'] = $metaWhere['key'];
            $args['meta_value'] = $metaWhere['value'];
            $args['compare'] = 'LIKE';
        }

        $posts = get_posts($args);

        return array_map(
            function (WP_Post $post) use ($postClass) {
                return new $postClass($post->ID);
            },
            $posts
        );
    }

    /**
     * validate
     *
     * Validate the metabox fields prior to data being saved in the database
     *
     * @param int $postId
     */
    public function validate(int $postId)
    {
        $errors = [];
        foreach ($this->postType->getFields() as $fieldID => $config) {
            if ($config['required'] ?? false) {
                // This is a required field
                if (empty($this->data[$fieldID])) {
                    $errors[] = $config['fieldTitle'].' is a required field';
                }
            }
        }
        if ($errors) {
            update_option('my_notifications', json_encode($errors));
            header('Location: '.get_edit_post_link($postId, 'redirect'));
            exit;
        }
    }

    /**
     * save
     *
     * Save the post's metabox data
     *
     * @throws Exception
     */
    public function save()
    {
        // Check if the current user can edit the post
        if (!current_user_can('edit_post', $this->postID)) {
            throw new Exception('You do not have the required permissions');
        }

        // If we have data
        if (!empty($this->data)) {
            // Loop through data
            foreach ($this->data as $fieldID => $value) {
                // If the field needs to be saved
                if ($this->postType->getFields()[$fieldID]['saveValue']) {
                    // Sanitize data
                    switch ($this->postType->getFields()[$fieldID]['fieldType']) {
                        case 'text':
                            $value = sanitize_text_field($value);
                            break;
                        case 'email':
                            $value = sanitize_email($value);
                            break;
                        case 'number':
                            $value = (float) $value;
                            break;
                    }

                    // Save the data
                    update_post_meta($this->postID, $fieldID, $value);
                }
            }
        }
    }
}
