<?php
/**
 * Define constants required for the framework plugin
 */

// Set plugin root
define('IF_PLUGIN_ROOT', plugin_dir_path(__FILE__));

// Plugin slug
define('IF_PLUGIN_SLUG', basename(plugin_dir_path(__FILE__)));

// Plugin title
define('IF_PLUGIN_TITLE', ucwords(str_replace('-', ' ', IF_PLUGIN_SLUG)));

// Path to views folder
define('IF_VIEWS_FOLDER', IF_PLUGIN_ROOT.'src/Views');
