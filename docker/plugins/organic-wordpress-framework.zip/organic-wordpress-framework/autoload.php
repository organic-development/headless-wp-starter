<?php
/**
 * Autoload
 */
require 'definitions.php';
require __DIR__.'/src/Autoloader.php';
OrganicFramework\Autoloader::registerNamespace('OrganicFramework', __DIR__.'/src');
