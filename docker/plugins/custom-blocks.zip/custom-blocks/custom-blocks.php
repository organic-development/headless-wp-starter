<?php
/**
 * Plugin Name:     Custom Blocks
 * Plugin URI:      https://theorganicagency.com
 * Description:     Provides custom blocks specific to this website
 * Author:          The Organic Agency
 * Author URI:      https://theorganicagency.com
 * Text Domain:     wp-headless
 * Domain Path:     /languages
 * Version:         0.1.0
 */

const GOOGLE_MAPS_API_KEY = '';

/* https://wpdevelopment.courses/a-list-of-all-default-gutenberg-blocks-in-wordpress-5-0/ */
const ALLOWED_CORE_BLOCKS = [
    'core/paragraph',
    'core/image',
    'core/heading',
    'core/list',
    'core/file',
    'core/more',
    'core/columns',
    'core/media-text',
    'core/button',
    'core/columns',
    'core/spacer',
    'core/separator',
    'core/video',
    'core-embed/vimeo',
];

require __DIR__.'/../organic-wordpress-framework/autoload.php';

$framework = new OrganicFramework\Framework('custom-blocks', 'CustomBlocks', __DIR__.'/src');
$framework->registerCustomPostTypeDirectory(__DIR__.'/src/CustomPostTypes');
$framework->registerEditorCss('dist/blocks.editor.build.css');
$framework->registerFrontEndCss('dist/blocks.style.build.css');
$framework->registerBlocksJs(
    'dist/blocks.build.js',
    [
        'wp-blocks',
        'wp-editor',
        'wp-edit-post',
        'wp-element',
        'wp-i18n',
        'wp-plugins',
    ]
);
$framework->registerBlockDirectory(__DIR__.'/src/Blocks');
$framework->registerApiDirectory(__DIR__.'/src/ApiRoutes');

// Only whitelist blocks below, along with any defined in 'ALLOWED_CORE_BLOCKS' if user is not admin.
// Must hook 'plugins_loaded' so that wp_current_user works.
add_action('plugins_loaded', function () use ($framework) {
    // Only whitelist blocks below, along with any defined in 'ALLOWED_CORE_BLOCKS' if user is not admin
    if (!current_user_can('administrator')) {
        $framework->whitelistBlocks(
            [
                'custom-blocks/office',
                'custom-blocks/support',
            ]
        );
    }
});

$framework->registerBlockCategories(
    [
        'about',
        'support',
    ]
);

$framework->run();
