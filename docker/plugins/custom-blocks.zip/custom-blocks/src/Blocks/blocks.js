// Wordpress' built-in function to register a Gutenberg block component
const { registerBlockType } = wp.blocks;

// The namespace for this plugin's components
const namespace = 'custom-blocks';

// Tell Webpack to look for all index.js files in the Blocks directory
const context = require.context('./', true, /index\.js$/);

// Loop through all our imported blocks and register them with WordPress
context.keys().forEach(modulePath => {

    // Get the actual JS module, as provided by Webpack
    const module = context(modulePath);

    // Extract the module name from the path
    const moduleName = modulePath.substring('./'.length, modulePath.lastIndexOf('/')).toLowerCase();

    // We expect all our block modules to return a default object literal,
    // which defines the React component.
    registerBlockType(namespace + '/' + moduleName, module.default);
});

import './editor.scss';
