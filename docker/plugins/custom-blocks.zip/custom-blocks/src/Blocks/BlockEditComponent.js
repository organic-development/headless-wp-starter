const { Component } = wp.element;

/**
 * This class provides a standard base class for any Gutenberg block edit components. It saves having to write
 * attribute updating code in each one.
 */
export default class BlockEditComponent extends Component {
    /**
     * Given an attribute name, returns a function which will handle updating the attributes object.
     * Typically supplied as the "change handler" on a form input.
     */
    update(key) {
        const { attributes, setAttributes } = this.props;
        return (value) => {
            const newAttributes = { ...attributes, ...{ [key]: value } };
            setAttributes(newAttributes);
        };
    }

    getIntroTextPlaceholder() {
        return 'Add intro text...';
    }

    getTextContentPlaceholder() {
        return 'Add text content...';
    }

    getHeadingPlaceholder() {
        return 'Add heading...';
    }

    getButtonTextPlaceholder() {
        return 'Add button text...';
    }
}
