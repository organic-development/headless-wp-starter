/**
 * Internal dependencies
 */
import edit from './edit';
import './styles/editor.scss';
import './styles/style.scss';

export default {
    title: 'Office Details',
    icon: 'smiley',
    category: 'about',

    attributes: {
        latLng: {
            type: 'string',
            source: 'meta',
            meta: 'Office.latlng'
        },
        address1: {
            type: 'string',
            source: 'meta',
            meta: 'Office.address1'
        },
        address2: {
            type: 'string',
            source: 'meta',
            meta: 'Office.address2'
        },
        address3: {
            type: 'string',
            source: 'meta',
            meta: 'Office.address3'
        },
        address4: {
            type: 'string',
            source: 'meta',
            meta: 'Office.address4'
        },
        postcode: {
            type: 'string',
            source: 'meta',
            meta: 'Office.postcode'
        }
    },

    edit,

    // No information saved to the block
    // Data is saved to post meta via attributes
    save() {
        return null;
    }
};
