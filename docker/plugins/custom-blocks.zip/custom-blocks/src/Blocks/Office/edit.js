import BlockEditComponent from '../BlockEditComponent';

const { TextControl } = wp.components;

export default class OfficeEditBlock extends BlockEditComponent {

    render() {
        const { attributes } = this.props;
        const { latLng, address1, address2, address3, address4, postcode } = attributes;

        return (
            <div className={this.props.className}>
                <h2>Office Location</h2>
                <div className="address">
                    <label>Address</label>
                    <div className="address1">
                        <TextControl
                            placeholder="Address 1"
                            value={address1}
                            onChange={this.update('address1')}
                        />
                    </div>

                    <div className="address2">
                        <TextControl
                            placeholder="Address 2"
                            value={address2}
                            onChange={this.update('address2')}
                        />
                    </div>

                    <div className="address3">
                        <TextControl
                            placeholder="Address 3"
                            value={address3}
                            onChange={this.update('address3')}
                        />
                    </div>

                    <div className="address4">
                        <TextControl
                            placeholder="Address 4"
                            value={address4}
                            onChange={this.update('address4')}
                        />
                    </div>

                    <div className="postcode">
                        <TextControl
                            label="Postcode"
                            value={postcode}
                            onChange={this.update('postcode')}
                        />
                    </div>
                </div>

                <div className="lat-lng">
                    <TextControl
                        label="Lat/Long"
                        placeholder="Google Maps > right click > 'What's here?'..."
                        value={latLng}
                        onChange={this.update('latLng')}
                    />
                </div>

            </div>
        );
    }
}
