<?php

namespace CustomBlocks\CustomPostTypes;

use OrganicFramework\CustomPostTypes\AbstractCustomPostType;
use OrganicFramework\Interfaces\CustomPostTypeInterface;

class Support extends AbstractCustomPostType implements CustomPostTypeInterface
{
    const KEY = 'support';
    const SLUG = 'support';

    public static function getKey(): string
    {
        return self::KEY;
    }

    public static function getTypeSlug(): string
    {
        return self::SLUG;
    }

    public static function getNameSingular(): string
    {
        return 'Support Article';
    }

    public static function getNamePlural(): string
    {
        return 'Support Articles';
    }

    public static function getOptions(): array
    {
        return [
            'has_archive' => false,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-lightbulb',
            'rewrite'   => ['slug' => 'support/%category%'],
            'labels' => [
                'menu_name' => 'Support',
            ],
            'supports' => [
                'title',
                'editor',
                'revisions',
                'custom-fields',
            ],
            'template' => [
                ['core/paragraph'],
            ],
            'taxonomies' => [
                'category',
            ],
        ];
    }

    public static function useCustomiser(): bool
    {
        return true;
    }

    public static function getPostsPerPage(): int
    {
        return -1;
    }
}
