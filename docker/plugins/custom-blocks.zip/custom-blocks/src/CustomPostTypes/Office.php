<?php

namespace CustomBlocks\CustomPostTypes;

use OrganicFramework\CustomPostTypes\AbstractCustomPostType;
use OrganicFramework\Interfaces\CustomPostTypeInterface;

class Office extends AbstractCustomPostType implements CustomPostTypeInterface
{
    const KEY = 'office';
    const SLUG = 'office';

    /**
     * @var string
     * @meta
     */
    protected $latlng;
    /**
     * @var string
     * @meta
     */
    protected $address1;
    /**
     * @var string
     * @meta
     */
    protected $address2;
    /**
     * @var string
     * @meta
     */
    protected $address3;
    /**
     * @var string
     * @meta
     */
    protected $address4;
    /**
     * @var string
     * @meta
     */
    protected $postcode;

    public static function getKey(): string
    {
        return self::KEY;
    }

    public static function getTypeSlug(): string
    {
        return self::SLUG;
    }

    public static function getNameSingular(): string
    {
        return 'Office';
    }

    public static function getNamePlural(): string
    {
        return 'Offices';
    }

    public static function getOptions(): array
    {
        return [
            'has_archive' => true,
            'menu_icon' => 'dashicons-building',
            'labels' => [
                'menu_name' => 'Offices',
            ],
            'supports' => [
                'title',
                'editor',
                'custom-fields',
                'page-attributes',
            ],
            'template' => [
                ['custom-blocks/office'],
            ],
            'exclude_from_search' => true,
        ];
    }

    public static function allowedBlocks()
    {

        $blocks = (current_user_can('administrator')) ? [] : ['custom-blocks/office'];

        return $blocks;
    }

    public function getAddress(): string
    {
        $parts = array_filter(
            [
                '<b>'.$this->address1.'</b>',
                $this->address2,
                $this->address3,
                $this->address4,
            ]
        );

        return implode(',<br>', $parts);
    }

    public function getLatlng(): ?string
    {
        return $this->latlng;
    }

    public function getLat(): string
    {
        return trim(explode(',', $this->latlng)[0]);
    }

    public function getLng(): string
    {
        return trim(explode(',', $this->latlng)[1]);
    }

    public function getGoogleMapsLink(): string
    {
        return "https://www.google.com/maps/?q=".$this->getLat().",".$this->getLng()."";
    }

    public static function useCustomiser(): bool
    {
        return true;
    }

    public static function getPostsPerPage(): int
    {
        return -1;
    }

    public static function getCurrentSorting(): array
    {
        return [
            'order' => 'ASC',
            'orderBy' => 'menu_order',
        ];
    }
}
