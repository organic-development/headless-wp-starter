import './styles/editor.scss';

const { Component } = wp.element;
const { CheckboxControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

class ProductMultiSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
        this.values = new Set(this.props.value || []);
    }

    componentDidMount() {
        // Fetch the list of products from our custom API endpoint
        apiFetch({ path: 'iris/products' }).then(posts => {
            const options = posts.map(({ id: value, name: label }) => ({ label, value }));

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    renderCheckbox(attrs) {
        const { value, label } = attrs;
        const { onChange } = this.props;
        const checked = this.values.has(value);
        return (
            <CheckboxControl
                key={value}
                label={label}
                value={value}
                checked={checked}
                onChange={(isChecked) => {
                    isChecked ? this.values.add(value) : this.values.delete(value);
                    const newProductIds = Array.from(this.values);
                    onChange(newProductIds);
                }}
            />
        );
    }

    renderCheckboxes() {
        return this.state.options.map(option => this.renderCheckbox({ ...option }));
    }

    render() {
        const { label } = this.props;
        return (
            <div className="component-product-multi-select">
                <label>{label}</label>
                <div className="checkboxes">
                    {this.renderCheckboxes()}
                </div>
            </div>
        );
    }
}

export default withState()(ProductMultiSelect);
