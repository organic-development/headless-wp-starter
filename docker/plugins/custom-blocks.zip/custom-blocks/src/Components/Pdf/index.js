import icon from './icon';
import './styles/editor.scss';

const apiFetch = wp.apiFetch;
const { BlockIcon, MediaPlaceholder, MediaUpload } = wp.editor;
const { Component, Fragment } = wp.element;

const ALLOWED_MEDIA_TYPES = ['application/pdf'];

/**
 * Provide a PDF file upload/picker component
 */
export default class Pdf extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            url: ''
        };
    }

    componentDidMount() {
        // Value will be the post ID of the image
        const { value } = this.props;
        // Fetch the details of the image from the WP API
        if (value) {
            apiFetch({ path: 'wp/v2/media/' + value }).then(media => {
                // Once the results come back, update the internal state of the component
                this.setState({ url: media.source_url });
            });
        }
    }

    renderPlaceHolder() {
        const { onChange, className, labels } = this.props;
        const labelsWithDefaults = { ...{ title: 'PDF' }, ...labels };
        return (
            <MediaPlaceholder
                className={className}
                icon={<BlockIcon icon={icon}/>}
                onSelect={(media) => {
                    this.setState({ url: media.url });
                    onChange(media.id);
                }}
                allowedTypes={ALLOWED_MEDIA_TYPES}
                multiple={false}
                labels={labelsWithDefaults}
            />
        );
    }

    renderPdf() {
        const { onChange, value, className } = this.props;
        const { url } = this.state;
        return (
            <div className="iris-pdf-component">
                <figure className={className}>
                    <MediaUpload
                        onSelect={(media) => {
                            this.setState({ url: media.url });
                            onChange(media.id);
                        }}
                        allowedTypes={ALLOWED_MEDIA_TYPES}
                        value={value}
                        render={({ open }) => {
                            return (
                                <button onClick={open}>{url}</button>
                            );
                        }}
                    />
                </figure>
            </div>
        );
    }

    render() {
        // Value is the post ID of the pdf
        const { value } = this.props;

        return (
            <Fragment>
                {value ? this.renderPdf() : this.renderPlaceHolder()}
            </Fragment>
        );
    }
}
