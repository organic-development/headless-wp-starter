const { Component, Fragment } = wp.element;
const { CheckboxControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

/**
 * Provide a select input element populated with Sectors. Allows for multiple-sectors to be selected.
 */
class SectorMultiSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
        this.values = new Set(this.props.value || []);
    }

    componentDidMount() {
        // Fetch the list of question groups from the Wordpress API
        apiFetch({ path: 'wp/v2/sector?per_page=100' }).then(posts => {
            const options = posts.map(post => {
                return {
                    label: post.title.rendered,
                    value: post.id
                };
            });

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    renderCheckbox(attrs) {
        const { value, label } = attrs;
        const { onChange } = this.props;
        const checked = this.values.has(value);
        return (
            <CheckboxControl
                key={value}
                label={label}
                value={value}
                checked={checked}
                onChange={(isChecked) => {
                    isChecked ? this.values.add(value) : this.values.delete(value);
                    const newSectorIds = Array.from(this.values);
                    onChange(newSectorIds);
                }}
            />
        );
    }

    renderCheckboxes() {
        return this.state.options.map(option => this.renderCheckbox({ ...option }));
    }

    render() {
        const { label } = this.props;
        return (
            <Fragment>
                <label>{label}</label>
                <div className="checkboxes">
                    {this.renderCheckboxes()}
                </div>
            </Fragment>
        );
    }
}

export default withState()(SectorMultiSelect);
