const { Component } = wp.element;
const { SelectControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

/**
 * Provide a list of selectable Marketo forms. Relies on the "Ultimate Marketo Forms" plugin.
 */
class FormSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
    }

    componentDidMount() {
        // Fetch the list of question groups from the Wordpress API
        apiFetch({ path: 'iris/forms' }).then(forms => {
            const options = forms.map(form => {
                return {
                    label: form.form_name,
                    value: form.form_id
                };
            });

            // Add an empty option at the top
            options.unshift({
                label: 'Please select...',
                value: '0'
            });

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    render() {
        const { value, onChange, label } = this.props;

        return (
            <SelectControl
                label={label}
                value={value}
                options={this.state.options}
                onChange={onChange}
            />
        );
    }
}

export default withState()(FormSelect);
