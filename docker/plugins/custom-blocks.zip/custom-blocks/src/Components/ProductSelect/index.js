const { Component } = wp.element;
const { SelectControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

class ProductSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
    }

    componentDidMount() {
        // Fetch the list of products from our custom API endpoint
        apiFetch({ path: 'iris/products' }).then(posts => {
            const options = posts.map(({ id: value, name: label }) => ({ label, value }));

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    render() {
        const { value, onChange, label } = this.props;

        return (
            <SelectControl
                label={label}
                value={value}
                options={this.state.options}
                onChange={onChange}
            />
        );
    }
}

export default withState()(ProductSelect);
