const { Component, Fragment } = wp.element;
const { CheckboxControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

class suiteMultiSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
        this.values = new Set(this.props.value || []);
    }

    componentDidMount() {
        apiFetch({ path: 'iris/suites' }).then(suites => {
            const options = suites.map(suite => {
                return {
                    label: `${suite.name}`,
                    value: suite.id
                };
            });

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    renderCheckbox(attrs) {
        const { value, label } = attrs;
        const { onChange } = this.props;
        const checked = this.values.has(value);
        return (
            <CheckboxControl
                key={value}
                label={label}
                value={value}
                checked={checked}
                onChange={(isChecked) => {
                    isChecked ? this.values.add(value) : this.values.delete(value);
                    const newSectorIds = Array.from(this.values);
                    onChange(newSectorIds);
                }}
            />
        );
    }

    renderCheckboxes() {
        return this.state.options.map(option => this.renderCheckbox({ ...option }));
    }

    render() {
        const { label } = this.props;
        return (
            <Fragment>
                <label>{label}</label>
                <div className="checkboxes">
                    {this.renderCheckboxes()}
                </div>
            </Fragment>
        );
    }
}

export default withState()(suiteMultiSelect);
