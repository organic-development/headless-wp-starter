const { Component } = wp.element;
const { SelectControl } = wp.components;
const { withState } = wp.compose;
const apiFetch = wp.apiFetch;

/**
 * Provide a list of selectable Sectors as a Select input element
 */
class SectorSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: []
        };
    }

    componentDidMount() {
        // Fetch the list of question groups from the Wordpress API
        apiFetch({ path: 'wp/v2/sector?per_page=100' }).then(posts => {
            const options = posts.map(post => {
                return {
                    label: post.title.rendered,
                    value: post.id
                };
            });

            if (this.props.optional) {
                options.unshift({
                    label: 'None',
                    value: ''
                });
            }

            // Once the results come back, update the internal state of the component
            this.setState({ options });
        });
    }

    render() {
        const { value, onChange, label } = this.props;

        return (
            <SelectControl
                label={label}
                value={value}
                options={this.state.options}
                onChange={onChange}
            />
        );
    }
}

export default withState()(SectorSelect);
