const { Component } = wp.element;
const { SelectControl } = wp.components;
const { withState } = wp.compose;

class YesNoSelect extends Component {

    constructor() {
        super(...arguments);
        this.state = {
            options: [{ label: 'No', value: 0 }, { label: 'Yes', value: 1 }]
        };
    }

    render() {
        const { value, onChange, label } = this.props;

        return (
            <SelectControl
                label={label}
                value={value}
                options={this.state.options}
                onChange={onChange}
            />
        );
    }
}

export default withState()(YesNoSelect);
